use octa_force::{glam::{IVec3, UVec3, Vec3A}, log::debug, OctaResult};
use smallvec::SmallVec;


use crate::{util::{math::get_dag_node_children_i, math_config::MC, number::Nu, vector::Ve}, volume::VolumeQureyPosValue, voxel::dag64::{entry::{DAG64Entry, DAG64EntryKey}, lod_heuristic::LODHeuristicT, node::VoxelDAG64Node, single::VoxelDAG64, util::get_dag_offset_levels}};

impl VoxelDAG64 { 
    pub fn add_pos_query_volume<V: Ve<T, 3>, T: Nu, M: VolumeQureyPosValue<V, T, 3>, LOD: LODHeuristicT>(
        &mut self, 
        model: &M,
        lod: &LOD,
    ) -> OctaResult<DAG64EntryKey> {
        let (offset, levels) = get_dag_offset_levels(model);
        if levels == 0 {
            return self.empty_entry();
        }

        let root = self.add_pos_query_recursive(model, lod, offset, levels)?;
        let root_index = self.nodes.push(&[root])?;
        let key = self.entry_points.insert(DAG64Entry { 
            levels, 
            root_index, 
            offset, 
        });

        Ok(key)
    }

    pub(super) fn add_pos_query_recursive<V: Ve<T, 3>, T: Nu, M: VolumeQureyPosValue<V, T, 3>, LOD: LODHeuristicT>(
        &mut self,
        model: &M,
        lod: &LOD,
        offset: IVec3,
        node_level: u8,
    ) -> OctaResult<VoxelDAG64Node> {
        let mut bitmask = 0;

        if node_level <= lod.lod_level(offset) {
            self.add_pos_query_leaf(model, offset, node_level)
        } else {
            let new_level = node_level -1;
            let new_scale = 4_i32.pow(new_level as u32);
            let mut nodes = SmallVec::<[_; 64]>::new();

            for (i, pos) in get_dag_node_children_i().into_iter().enumerate() {
                let child = self.add_pos_query_recursive(
                    model,
                    lod,
                    offset + pos * new_scale,
                    new_level,
                )?;
                if !child.is_empty() {
                    nodes.push(child);
                    bitmask |= 1 << i as u64;
                }
            }

            Ok(VoxelDAG64Node::single(false, self.nodes.push(&nodes)? as u32, bitmask))
        }
    }

    pub(super) fn add_pos_query_leaf<V: Ve<T, 3>, T: Nu, M: VolumeQureyPosValue<V, T, 3>>(
        &mut self,
        model: &M,
        offset: IVec3,
        node_level: u8,
    ) -> OctaResult<VoxelDAG64Node> {
        let mut vec = SmallVec::<[_; 64]>::new();
        let mut bitmask = 0;

        for (i, pos) in get_dag_node_children_i().into_iter().enumerate() {
            let pos = offset + pos;
            let value = model.get_value(V::ve_from(pos));

            if value != 0 {
                vec.push(value);
                bitmask |= 1 << i as u64;
            }
        } 

        let ptr = self.data.push(&vec)?;
        Ok(VoxelDAG64Node::single(true, ptr, bitmask))
    }
}
