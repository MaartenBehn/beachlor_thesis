use std::{collections::{HashMap, VecDeque}, fmt::{Debug, Octal}, iter, marker::PhantomData, mem::{self, ManuallyDrop}, task::ready, usize};

use enum_dispatch::enum_dispatch;
use itertools::{Either, Itertools};
use octa_force::{anyhow::{anyhow, bail, ensure}, glam::{vec3, vec3a, IVec3, Vec3, Vec3Swizzles}, log::{debug, error, info}, vulkan::ash::vk::OpaqueCaptureDescriptorDataCreateInfoEXT, OctaResult};
use rayon::iter::IntoParallelIterator;
use slotmap::{new_key_type, Key, SlotMap};
use smallvec::SmallVec;
use crate::{model::{composer::output_state::OutputState, data_types::{data_type::{CollapseValue, TemplateValue}, mesh::MeshCollapserData, voxels::VoxelCollapserData}, template::{Template, TemplateIndex}}, util::{default_types::{T, V3}, iter_merger::{IM2, IM3}, number::Nu, state_saver, vector::Ve}, volume::{VolumeBounds, VolumeQureyPosValid}};

use super::{add_nodes::{GetNewChildrenData, GetValueData}, external_input::ExternalInput, pending_operations::{PendingOperations, PendingOperationsRes}};

new_key_type! { pub struct CollapseNodeKey; }
new_key_type! { pub struct CollapseChildKey; }

#[derive(Debug, Clone)]
pub struct Collapser {
    pub nodes: SlotMap<CollapseNodeKey, CollapseNode>,
    pub nodes_per_template_index: Vec<SmallVec<[CollapseNodeKey; 4]>>,
    pub pending: PendingOperations,
    pub template: Template,
    pub external_input: ExternalInput,
    pub state: OutputState,

    pub seq: Option<Sequences>,
}

#[derive(Debug, Clone)]
pub struct CollapseNode {
    pub template_index: usize,
    pub children: Vec<(TemplateIndex, Vec<(CollapseNodeKey, CollapseChildKey)>)>, 
    pub depends: Vec<(TemplateIndex, Vec<(CollapseNodeKey, CollapseChildKey)>)>,
    pub defined_by: CollapseNodeKey,
    pub child_key: CollapseChildKey,
    pub data: CollapseValue,
    pub next_reset: CollapseNodeKey,
}

#[derive(Debug, Clone)]
pub struct Sequences {
    pub seq_2d: quasi_rd::Sequence,
    pub seq_3d: quasi_rd::Sequence,
}

#[enum_dispatch]
pub trait CollapseValueT {
    fn on_delete(&self, state: &mut OutputState);
}

union VUnion<VA: Ve<T, DA>, VB: Ve<T, DB>, T: Nu, const DA: usize, const DB: usize> {
    a: VA,
    b: VB,
    p: PhantomData<T>,
}

union PairUnion<VA: Ve<T, DA>, VB: Ve<T, DB>, T: Nu, const DA: usize, const DB: usize> {
    a: (VA, VA),
    b: (VB, VB),
    p: PhantomData<T>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct UpdateDefinesOperation { 
    pub template_index: TemplateIndex,
    pub parent_index: CollapseNodeKey,
    pub creates_index: usize,
}

impl Collapser {
    pub async fn new(
        template: Template, 
        external_input: ExternalInput,
        state: OutputState,
) -> Self {
        let inital_capacity = 1000;

        let seq = Sequences {
            seq_2d: quasi_rd::Sequence::new_with_offset(2, fastrand::u64(0..=u64::MAX)),
            seq_3d: quasi_rd::Sequence::new_with_offset(3, fastrand::u64(0..=u64::MAX)),
        };

        let mut collapser = Self {
            nodes: SlotMap::with_capacity_and_key(inital_capacity),
            pending: PendingOperations::new(template.max_level),
            nodes_per_template_index: vec![SmallVec::new(); template.nodes.len()],
            template,
            external_input,
            state,
            seq: Some(seq),
        };

        collapser.add_node(
            0, 
            vec![], 
            CollapseNodeKey::null(), 
            CollapseChildKey::null()).await;

        collapser.pending.push_collpase(1, collapser.get_root_key());

        collapser
    }
 
    pub async fn run(&mut self) {

        loop {
            match self.pending.pop() {
                PendingOperationsRes::Collapse(key) => self.collapse_node(
                    key).await,

                PendingOperationsRes::CreateDefined(operation) => self.update_defined(
                    operation).await,

                PendingOperationsRes::Retry => {
                    #[cfg(debug_assertions)]
                    info!("Swaped Next Collapse");
                },
                PendingOperationsRes::Empty => break,
            }
        }
    }

    async fn collapse_node(&mut self, node_index: CollapseNodeKey) {

        if !self.nodes.contains_key(node_index) {
            return;
        }
        
        let node = &self.nodes[node_index];
        let template_node = &self.template.nodes[node.template_index]; 
        let value = &self.template.values[template_node.value_index];

        #[cfg(debug_assertions)]
        info!("{:?} Collapse", node_index);

        let get_value_data = GetValueData { 
            defined_by: node.defined_by, 
            depends: &node.depends, 
            depends_loop: &template_node.depends_loop,
            external_input: self.external_input,
        }; 
        let mut seq = self.seq.take().unwrap();

        let needs_recompute = match value {
            TemplateValue::None => false,
            TemplateValue::NumberSet(space) => {
                todo!();
                let (mut new_val, r) = space.get_value(get_value_data, &self);
                let new_val = new_val.next().unwrap(); 

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::NumberSet(space) => space,
                    _ => unreachable!()
                };

                // TODO random select
                data.update(new_val); 

                r
            },
            TemplateValue::PositionSet2D(position_set_template) => {
                let (new_positions, r) = position_set_template.get_value(get_value_data, &mut seq,&self);

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::PositionSet2D(space) => space,
                    _ => unreachable!()
                };
                data.update(new_positions); 

                r
            },
            TemplateValue::PositionSet3D(position_set_template) => {
                let (new_positions, r) = position_set_template.get_value(get_value_data, &mut seq, &self);

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::PositionSet3D(space) => space,
                    _ => unreachable!()
                };
                data.update(new_positions); 

                r
            },
            TemplateValue::PositionPairSet2D(position_set_template) => {
                let (new_positions, r) = position_set_template.get_value(get_value_data, &mut seq, &self);

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::PositionPairSet2D(space) => space,
                    _ => unreachable!()
                };
                data.update(new_positions); 

                r
            },
            TemplateValue::PositionPairSet3D(position_set_template) => {
                let (new_positions, r) = position_set_template.get_value(get_value_data, &mut seq, &self);

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::PositionPairSet3D(space) => space,
                    _ => unreachable!()
                };
                data.update(new_positions); 

                r
            },
            TemplateValue::Voxels(voxel_template) => {

                let (mut volume, r_0) = self.template.get_volume_value(voxel_template.volume)
                    .get_value::<V3, u8, 3>(get_value_data, &self);

                let (mut pos, r_1) = self.template.get_position3d_value(voxel_template.pos)
                    .get_value(get_value_data, &self);

                let pos = pos[0];

                volume.calculate_bounds();

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::Voxels(voxels) => voxels,
                    _ => unreachable!()
                };
                data.update(volume, pos, &mut self.state).await; 
 
                false
            },
            TemplateValue::Mesh(mesh_template) => {

                let (mut volume, r_0) = self.template.get_volume_value(mesh_template.volume)
                    .get_value::<V3, u8, 3>(get_value_data, &self);

                let (mut pos, r_1) = self.template.get_position3d_value(mesh_template.pos)
                    .get_value(get_value_data, &self);

                let pos = pos[0];

                volume.calculate_bounds();

                let data = match &mut self.nodes[node_index].data {
                    CollapseValue::Mesh(mesh) => mesh,
                    _ => unreachable!()
                };
                data.update(volume, pos, &mut self.state).await; 
 
                false
            },
            _ => unreachable!(),
        };  

        self.seq = Some(seq);

        if needs_recompute {
            self.pending.push_later_collpase(template_node.level, node_index);
        }

        self.push_defined(node_index);
        self.collapse_all_childeren(node_index);
    }

    fn collapse_all_childeren(&mut self, node_index: CollapseNodeKey) {
        let node = &self.nodes[node_index];

        for (_, list) in node.children.iter() {
            for (child_index, _) in list.iter() {

                let child_node = &self.nodes[*child_index];
                let template_node = &self.template.nodes[child_node.template_index]; 
                self.pending.push_collpase(template_node.level, *child_index);
            }
        }
    }

    pub fn get_new_children(&self, index: CollapseNodeKey) -> impl Iterator<Item = CollapseChildKey> {
        let node = self.nodes.get(index)
            .expect("New Children Node not found");

        let keys = match &node.data {
            CollapseValue::NumberSet(number_space) => {
                todo!()
            },
            CollapseValue::PositionSet2D(s) => s.get_new_children(),
            CollapseValue::PositionSet3D(s) => s.get_new_children(),
            CollapseValue::PositionPairSet2D(s) => s.get_new_children(),
            CollapseValue::PositionPairSet3D(s) => s.get_new_children(),
            CollapseValue::Voxels(_)
            | CollapseValue::Mesh(_)
            | CollapseValue::None(_)
            => panic!("Called get new children on node that has no children"),
        };

        keys.into_iter()
            .copied()
    }

    pub fn is_child_valid(
        &self, 
        index: CollapseNodeKey,
        child_index: CollapseChildKey,
    ) -> bool {
        let node = self.nodes.get(index)
            .expect("Is Child Valid Node not found");

        match &node.data {
            CollapseValue::PositionSet2D(position_space) => position_space.is_child_valid(child_index),
            CollapseValue::PositionSet3D(position_space) => position_space.is_child_valid(child_index),
            CollapseValue::PositionPairSet2D(position_pair_set) => position_pair_set.is_child_valid(child_index),
            CollapseValue::PositionPairSet3D(position_pair_set) => position_pair_set.is_child_valid(child_index),
            CollapseValue::NumberSet(_)
            | CollapseValue::Voxels(_)
            | CollapseValue::Mesh(_)
            | CollapseValue::None(_) 
            => panic!("Called is child valid on node that has no children"),
        }
    }

    pub fn get_number(&self, index: CollapseNodeKey) -> T {
        let node = self.nodes.get(index)
            .expect("Number Set by index not found");

        let v = match &node.data {
            CollapseValue::NumberSet(d) => d.value,
            _ => panic!("Template Node {:?} is not of Type Number Space", node.template_index)
        };

        v
    }

    pub fn get_position<V: Ve<T, D>, const D: usize>(&self, parent_index: CollapseNodeKey, child_index: CollapseChildKey) -> V {
        let parent = &self.nodes[parent_index];
       
        match D {
            2 => {
                let v = match &parent.data {
                    CollapseValue::PositionSet2D(d) => d.get_position(child_index),
                    _ => panic!("Template Node {:?} is not of Type Position Set 2D Set", parent.template_index)
                };

                // Safety V2 and V are the same Type bause D == 2
                unsafe { VUnion{ a: v }.b }
            }
            3 => {
                let v = match &parent.data {
                    CollapseValue::PositionSet3D(d) => d.get_position(child_index),
                    _ => panic!("Template Node {:?} is not of Type Position Set 3D Set", parent.template_index)
                };

                // Safety V3 and V are the same Type bause D == 3
                unsafe { VUnion{ a: v }.b }
            }
            _ => unreachable!()
        }
    }

    pub fn get_positions<V: Ve<T, D>, const D: usize>(
        &self,
        parent_index: CollapseNodeKey, 
    ) -> impl Iterator<Item = V> {

        let parent = &self.nodes[parent_index];
       
        match D {
            2 => {
                let v = match &parent.data {
                    CollapseValue::PositionSet2D(d) => d.get_positions(),
                    _ => panic!("Template Node {:?} is not of Type Position Set 2D Set", parent.template_index)
                };

                // Safety V2 and V are the same Type bause D == 2
                IM2::A(v.map(|v| unsafe { VUnion{ a: v }.b }))
            }
            3 => {
                let v = match &parent.data {
                    CollapseValue::PositionSet3D(d) => d.get_positions(),
                    _ => panic!("Template Node {:?} is not of Type Position Set 3D Set", parent.template_index)
                };

                // Safety V3 and V are the same Type bause D == 3
                IM2::B(v.map(|v| unsafe { VUnion{ a: v }.b }))
            }
            _ => unreachable!()
        }
    }

    pub fn get_position_pair<V: Ve<T, D>, const D: usize>(&self, parent_index: CollapseNodeKey, child_index: CollapseChildKey) -> (V, V) {
        let parent = &self.nodes[parent_index];
       
        match D {
            2 => {
                let v = match &parent.data {
                    CollapseValue::PositionPairSet2D(d) => d.get_position_pair(child_index),
                    _ => panic!("Template Node {:?} is not of Type Position Pair Set 2D Set", parent.template_index)
                };

                // Safety V2 and V are the same Type bause D == 2
                unsafe { PairUnion{ a: v }.b }
            }
            3 => {
                let v = match &parent.data {
                    CollapseValue::PositionPairSet3D(d) => d.get_position_pair(child_index),
                    _ => panic!("Template Node {:?} is not of Type Position Pair Set 3D Set", parent.template_index)
                };

                // Safety V3 and V are the same Type bause D == 3
                unsafe { PairUnion{ a: v }.b }
            }
            _ => unreachable!()
        }
    }

    pub fn get_position_pairs<V: Ve<T, D>, const D: usize>(&self, parent_index: CollapseNodeKey) -> impl Iterator<Item = (V, V)> {
        let parent = &self.nodes[parent_index];
       
        match D {
            2 => {
                let v = match &parent.data {
                    CollapseValue::PositionPairSet2D(d) => d.get_position_pairs(),
                    _ => panic!("Template Node {:?} is not of Type Position Pair Set 2D Set", parent.template_index)
                };

                // Safety V2 and V are the same Type bause D == 2
                IM2::A(v.map(|v| unsafe { PairUnion{ a: v }.b }))
            }
            3 => {
                let v = match &parent.data {
                    CollapseValue::PositionPairSet3D(d) => d.get_position_pairs(),
                    _ => panic!("Template Node {:?} is not of Type Position Pair Set 3D Set", parent.template_index)
                };

                // Safety V3 and V are the same Type bause D == 3
                IM2::B(v.map(|v| unsafe { PairUnion{ a: v }.b }))
            }
            _ => unreachable!()
        }
    }
  
    fn get_dependend_index_value_data(
        &self, 
        template_index: TemplateIndex,
        get_value_data: GetValueData,
    ) -> (impl Iterator<Item = (CollapseNodeKey, CollapseChildKey)>, bool) {
        if let Some((_, keys)) = get_value_data.depends.iter().find(|(i, _)| *i == template_index) {
            return (IM3::A(keys.iter().copied()), false);
        }

        if let Some((_, loop_path)) = get_value_data.depends_loop.iter().find(|(i, _)| *i == template_index) {
            let keys = self.get_depends_from_loop_path(get_value_data, loop_path);
            (IM3::B(keys.into_iter()), false)
        } else {
            (IM3::C(iter::empty()), true)
        }

    }

    /*
    pub fn get_dependend_number(
        &self, 
        template_index: TemplateIndex,
        get_value_data: GetValueData,
    ) -> (impl Iterator<Item = T>, bool) {
        let (iter, r) = self.get_dependend_index_value_data(template_index, get_value_data);
        (iter.map(|i| self.get_number(i)), r)
    }
    */
     
    pub fn get_dependend_position<V: Ve<T, D>, const D: usize>(
        &self, 
        template_index: TemplateIndex,
        get_value_data: GetValueData,
    ) -> (impl Iterator<Item = V>, bool) {
        let (iter, r) = self.get_dependend_index_value_data(template_index, get_value_data);

        (iter.map(move |(i, child_key)| {

            if !child_key.is_null() {
                IM2::A(iter::once(self.get_position(i, child_key)))
            } else {
                IM2::B(self.get_positions(i))
            }
        }).flatten(), r)
    }

    pub fn get_dependend_position_pair<V: Ve<T, D>, const D: usize>(
        &self, 
        template_index: TemplateIndex,
        get_value_data: GetValueData,
    ) -> (impl Iterator<Item = (V, V)>, bool) { 
        let (iter, r) = self.get_dependend_index_value_data(template_index, get_value_data);
        
        (iter.map(move |(i, child_key)| {
            if !child_key.is_null() {
                IM2::A(iter::once(self.get_position_pair(i, child_key)))
            } else {
                IM2::B(self.get_position_pairs(i))
            }
        }).flatten(), r)        
    }

    pub fn get_root_key(&self) -> CollapseNodeKey {
        self.nodes.keys().next().unwrap()
    }
}
